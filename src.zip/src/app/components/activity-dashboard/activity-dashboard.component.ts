import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { Router } from '@angular/router';
Chart.register(...registerables);

@Component({
  selector: 'app-activity-dashboard',
  templateUrl: './activity-dashboard.component.html',
  styleUrls: ['./activity-dashboard.component.css']
})
export class ActivityDashboardComponent implements OnInit, AfterViewInit {
  activity = { date: '', transportation: '', energyUsage: '', wasteManagement: '' };
  goal = { transportationGoal: '', energyGoal: '', wasteGoal: '' };

  recognition: any;
  isListeningField: string | null = null;
  successMessage: string = '';
  errorMessage: string = '';
  todayDate: string = '';

  // Chart Variables
  userActivities: any[] = [];
  chart: Chart | null = null;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.todayDate = new Date().toISOString().split('T')[0];
    this.initializeSpeechRecognition();
  }

  ngAfterViewInit(): void {
    setTimeout(() => this.initializeChart(), 0); // Ensure the canvas exists before initialization
  }

  initializeSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window) {
      this.recognition = new (window as any).webkitSpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (this.isListeningField) {
          (this.activity as any)[this.isListeningField] = transcript;
        }
      };

      this.recognition.onerror = (event: any) => {
        console.error('Speech Recognition Error:', event.error);
      };

      this.recognition.onend = () => {
        this.isListeningField = null;
      };
    } else {
      console.warn('Speech Recognition API not supported in this browser.');
    }
  }

  startListening(field: string) {
    if (this.recognition) {
      this.isListeningField = field;
      this.recognition.start();
    }
  }

  submitActivity() {
    this.successMessage = '';
    this.errorMessage = '';

    const { date, transportation, energyUsage, wasteManagement } = this.activity;
    const today = new Date().toISOString().split('T')[0];

    if (!date || !transportation || !energyUsage || !wasteManagement) {
      this.errorMessage = 'Please fill in all fields before submitting.';
      return;
    }

    if (date > today) {
      this.errorMessage = 'You cannot enter activities for future dates.';
      return;
    }

    this.successMessage = `Your details for ${date} are saved!`;
  }

  submitGoal() {
    this.successMessage = `Your sustainability goals have been saved!`;
    console.log('Submitted Goal:', this.goal);
  }

  initializeChart() {
    const canvas = document.getElementById('activityChart') as HTMLCanvasElement;
    if (!canvas) {
      console.error('Canvas element not found!');
      return;
    }

    this.chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: [],
        datasets: [
          { label: 'Transportation (km)', data: [], backgroundColor: 'rgba(75, 192, 192, 0.6)' },
          { label: 'Energy Usage (kWh)', data: [], backgroundColor: 'rgba(255, 159, 64, 0.6)' },
          { label: 'Waste (kg)', data: [], backgroundColor: 'rgba(255, 99, 132, 0.6)' }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { beginAtZero: true },
          y: { beginAtZero: true }
        }
      }
    });
  }

  updateChart() {
    if (!this.chart) {
      console.error('Chart is not initialized.');
      return;
    }

    this.chart.data.labels = this.userActivities.map(activity => activity.date);
    this.chart.data.datasets[0].data = this.userActivities.map(activity => activity.transportation);
    this.chart.data.datasets[1].data = this.userActivities.map(activity => activity.energyUsage);
    this.chart.data.datasets[2].data = this.userActivities.map(activity => activity.wasteManagement);
    this.chart.update();
  }

  submitActivityForChart() {
    this.userActivities.push({
      date: this.activity.date,
      transportation: Number(this.activity.transportation),
      energyUsage: Number(this.activity.energyUsage),
      wasteManagement: Number(this.activity.wasteManagement)
    });

    this.updateChart();
  }

  navigateToGoalPage() {
    this.router.navigate(['/goals']);
  }
}
