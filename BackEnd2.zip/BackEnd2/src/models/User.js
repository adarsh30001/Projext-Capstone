// Module to create Genric User Object;
//List the reasons also

class User{

    constructor(obj) {
        this.name = obj.name;
        this.email = obj.email;
        this.password = obj.password;
        this.userType = (obj.userType || "individual")
        //this.sustainbilityGoals = null;
    }
}

//Exporting User;
module.exports = User;