import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-group-chat',
  templateUrl: './group-chat.component.html',
  styleUrls: ['./group-chat.component.css']
})
export class GroupChatComponent implements OnInit {
  chatForm: FormGroup;
  messages: {name:string, sender: string, text: string }[] = [];
  userId: string = '';
  userName: string = '';
  groupId: string = '';
  groupDetails: any = {};

  
  constructor(private fb: FormBuilder,private mainService: MainService,private route: ActivatedRoute) { 
    this.chatForm = this.fb.group({
      message: ['', Validators.required]
    });
    this.route.params.subscribe(params => {
      this.groupId = params['id'];
    });
    let token = this.mainService.getToken()??"";
    this.userId = this.mainService.decodeJWT(token)._id;
    this.userName = this.mainService.decodeJWT(token).name;
  }
  ngOnInit(): void {
    this.getAllMessages();
    this.getGroupDetailsById();
  }
  
  sendMessage() {
    if (this.chatForm.valid) {
      this.mainService.sendMessage(this.groupId,this.chatForm.value.message).subscribe({
        next: (res) => {
          console.log(res);
        },
        error: (err) => {
          console.log(err);
        }
        ,
        complete: () => {
          console.log('Completed');
        }
      })
      this.messages.push({ name:this.userName,sender: this.userId, text: this.chatForm.value.message });
      this.chatForm.reset();
    }
  }

  getAllMessages() {
    this.mainService.getAllMessages(this.groupId).subscribe({
      next: (res) => {
        console.log(res);
        this.messages = res.map((message: any) => {
          return {name:message.username, sender: message.senderId, text: message.message };
        });
      },
      error: (err) => {
        console.log(err);
      }
      ,
      complete: () => {
        console.log('Completed');
      }
    });
    }

    getGroupDetailsById() {
      this.mainService.getGroupDetailsById(this.groupId).subscribe({
        next: (res) => {
          console.log(res);
          this.groupDetails = res;
        },
        error: (err) => {
          console.log(err);
        }
        ,
        complete: () => {
          console.log('Completed');
        }
      });
      }
}
