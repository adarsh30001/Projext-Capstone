const router = require("express").Router();

// 1. Create Group
router.post('/group', async (req, res) => {
    const group = new Group(req.body);
    await group.save();
    res.send(group);
});

// 2. Update Group Name
router.post('/group', async (req, res) => {
    router.put('/group/:id', async (req, res) => {
    const group = await Group.findByIdAndUpdate(req.params.id, { name: req.body.name, updatedAt: Date.now() }, { new: true });
    res.send(group);
})});

// 3. Join Group
router.post('/group', async (req, res) => {
    router.put('/group/join/:id', async (req, res) => {
    const group = await Group.findByIdAndUpdate(req.params.id, {
        $push: { members: { _id: req.body.userId, name: req.body.name } },
        updatedAt: Date.now()
    }, { new: true });
    res.send(group);
})});

// 4. Get Unjoined Groups
router.get('/groups/unjoined/:userId', async (req, res) => {
    const groups = await Group.find({ "members._id": { $ne: req.params.userId } });
    res.send(groups);
});

// 5. Get Joined Groups
router.get('/groups/joined/:userId', async (req, res) => {
    const groups = await Group.find({ "members._id": req.params.userId });
    res.send(groups);
});

// 6. Send Message
router.post('/message', async (req, res) => {
    const message = new Message(req.body);
    await message.save();
    res.send(message);
});

// 7. Get Messages by Group ID
router.get('/messages/:groupId', async (req, res) => {
    const messages = await Message.find({ groupId: req.params.groupId });
    res.send(messages);
})

