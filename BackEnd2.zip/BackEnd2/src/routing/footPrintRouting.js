//To Track Carbon Footprint and Take sustainbility Goals
//Try and Catch Every Handler
const dbService = require("../services/mainService");
const User  = require("../models/User");
const router = require("express").Router();
const jwt = require("jsonwebtoken");
const auth = require("../utilities/auth");
const FootPrint = require("../models/FootPrint");
const isAdmin = require("./isAdmin");
//###3

//###3.1 Track CarbonFootprint 
router.post("/carbon-footprint",auth, async (req,res,next) =>{
   try {
        const {transportation, energyUsage, wasteDisposal} = req.body;

        const obj = {
            transportation,
            energyUsage,
            wasteDisposal
        };
        
        
        obj.date = (req.body.date || Date.now());
        obj._id = req.user._id;

        const footPrintObj = new FootPrint(obj);
        await dbService.addFootPrint(footPrintObj);

        res.status(200).json({"message" : "Carbon footprint tracked successfully"});
        next();
    
   }
   catch(err){
    next(err);
   }
})
//-------------------------------------------

//For Admin ??Add ISAdmin and Change to post
router.get("/footprint",auth,async (req,res,next) =>{
    const _id = req.user._id;
    const data = await dbService.getFootPrint(_id);
    //console.log(data);
    if(data) res.json(data.dailyActivities);

    else res.json({message :" No Goals Set"});
    next();
    
})
//-----------------------------------------

//For setting Goals which is [{goal,setAt,progress,category}]
router.post("goals",auth,async(req,res,next)=>{
    try{
        const {goal,category} = req.body;
        const goalsObj = {
            goal,
            category,
            setAt : (req.body.date || Date.now()),
        };
        const _id = req.user._id;  

        await dbService.updateOrAddGoal(_id,goalsObj);
        res.json({"message" : "Goal Set SuccessFully"});
        next();
    }
    catch(err){
        next(err);
    }



})

//4.2 Get user Goals

router.get("/goals", auth, async (req, res, next) => {
    try {
        const _id = req.user._id;
        //console.log(_id);
        const goals = await dbService.getSutainabilityGoals(_id);
        
        res.json( goals );
    } catch (err) {
        next(err);
    }
});

// Update Sustainbility Goals **4.3**
router.put("/goals",auth, async(req,res,next) =>{

    try{
        const {goal,category} = req.body;
        const goalsObj = {
            goal,
            category,
            setAt : (req.body.date || Date.now()),
        };
        const _id = req.user._id;  

        await dbService.updateOrAddGoal(_id,goalsObj);
        res.json({"message" : "Goal Set SuccessFully"});
        next();
    }
    catch(err){
        next(err);
    }

});

//Get Eco-friendly Tips for User **5.1**
router.get("/eco-tips",auth, async (req,res,next) =>{
    try {
        const tips = await dbService.getTips();
        res.json(tips?.[0]?.tips);
        next();
    }
    catch(err){
        next(err);
    }
});

//Post Tips From User **5.2**
router.post("/eco-tips",auth, async (req,res,next) =>{

    try {
        const {tip} = req.body;
        const user = await dbService.getUserProfile(req.user._id);
        const name = user.name;
        const tipObj = {tip,name};

        await dbService.postTips(tipObj);

        res.json({"message" : "Tip Shared Succefully"});
        next();
    }
    catch(err){
        next(err);
    }
})
//export footPrintRouter
module.exports = router