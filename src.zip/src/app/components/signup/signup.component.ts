// import { Component } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { MainService } from 'src/app/services/main.service';
// import { Router } from "@angular/router";

// @Component({
//   selector: 'app-signup',
//   templateUrl: './signup.component.html',
//   styleUrls: ['./signup.component.css'],
// })
// export class SignupComponent {
//   signupForm: FormGroup;
//   userTypes = ['individual', 'business'];
//   errorMessage = "";
//   successMessage = "";
  

//   constructor(private fb: FormBuilder, private mainService : MainService, private router : Router) {
//     this.signupForm = this.fb.group({
//       userType: ['individual', Validators.required], // Default to Individual
//       name: ['',[ Validators.required]],
//       email: ['', [Validators.required, Validators.email]],
//       password: ['', [Validators.required, Validators.minLength(6)]],
//     });

//     //Listen for changes in userType to update validators
//     this.signupForm.get('userType')?.valueChanges.subscribe((userType) => {
//       this.updateNameValidator(userType);
//     });
//   }

//   // Update the name field based on userType
//   updateNameValidator(userType: string) {
//     const nameControl = this.signupForm.get('name');
//     if (userType === 'business') {
//       nameControl?.setValidators([Validators.required,Validators.minLength(3)]);
//       nameControl?.setValue('');
//       nameControl?.updateValueAndValidity();
//     } 
//      else {
//       nameControl?.setValidators([Validators.required,Validators.minLength(3)]);
//       nameControl?.setValue('');
//       nameControl?.updateValueAndValidity();
//     }
//   }

//   // Handle form submission
//   onSignup() : void {
//     if (this.signupForm.valid) {
//      this.mainService.onSignup(this.signupForm.value).subscribe(
//       (response)=> {
//         //console.log(response);
//         this.successMessage = "Sign Up SuccessFull!",
//         setTimeout(() =>{ this.router.navigate(['/login'])},1000);
//         this.successMessage = "";
//         this.errorMessage = "";
//       },
//       (error) =>{
//         if(error.error.message.includes("duplicate")){
//           this.errorMessage = "Email Already Registerd!"
//         }
//         else {
//         this.errorMessage = "Error in Sign Up Try Again!!";
//         }
//       }
//      )

//     } 
//     else {
//       alert('Please fill out the form correctly.');
//     }
//   }
// }

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainService } from 'src/app/services/main.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent {
  signupForm: FormGroup;
  userTypes = ['individual', 'business'];
  errorMessage = "";
  successMessage = "";

  constructor(private fb: FormBuilder, private mainService: MainService, private router: Router) {
    this.signupForm = this.fb.group({
      userType: ['individual', Validators.required],
      name: ['', [
        Validators.required,
        Validators.minLength(3),
        this.noSpecialCharsValidator // Custom inline validator
      ]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });

    // Listen for changes in userType to update validators
    this.signupForm.get('userType')?.valueChanges.subscribe((userType) => {
      this.updateNameValidator(userType);
    });
  }

  // Update the name field based on userType
  updateNameValidator(userType: string) {
    const nameControl = this.signupForm.get('name');
    if (userType === 'business') {
      nameControl?.setValidators([Validators.required, Validators.minLength(3), this.noSpecialCharsValidator]);
      nameControl?.updateValueAndValidity();
    } else {
      nameControl?.setValidators([Validators.required, Validators.minLength(3), this.noSpecialCharsValidator]);
      nameControl?.updateValueAndValidity();
    }
  }

  // Custom validator to check for special characters
  noSpecialCharsValidator(control: any) {
    const value = control.value;
    const specialCharPattern = /[^a-zA-Z\s]/; // Excludes anything that's not a letter or space
    if (specialCharPattern.test(value)) {
      return { 'specialChar': true };
    }
    return null;
  }

  // Handle form submission
  onSignup(): void {
    if (this.signupForm.valid) {
      this.mainService.onSignup(this.signupForm.value).subscribe(
        (response) => {
          this.successMessage = "Sign Up Successful!";
          setTimeout(() => { this.router.navigate(['/login']) }, 1000);
          this.successMessage = "";
          this.errorMessage = "";
        },
        (error) => {
          if (error.error.message.includes("duplicate")) {
            this.errorMessage = "Email Already Registered!";
          } else {
            this.errorMessage = "Error in Sign Up. Try Again!";
          }
        }
      );
    } else {
      alert('Please fill out the form correctly.');
    }
  }
}
