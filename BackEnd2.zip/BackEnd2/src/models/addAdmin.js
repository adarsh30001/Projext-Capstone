//file to add admin
const User = require("./User");
const db = require("./dbSetUp");
const admin = new User({
    name : "Adarsh",
    password : "@12@!",
    email : "adarshalex201@gmail.com"
});

const addAddmin = async (admin)=> {
    admin.role = "admin";
    admin.uId = 0;
    const userModel = await db.getUserModel();
    const addAddmin = await userModel.create(admin);
    console.log("admin Added");
}

addAddmin(admin);


