import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit{
  isLoggedIn : boolean = false;
  constructor (private mainService : MainService, private router : Router) {}

  ngOnInit(): void {

    if(this.mainService.isAuthenticated()){
      this.isLoggedIn = true;
    }
    
  }

  logOut(){
    this.mainService.logout();
    this.router.navigate(["/login"]);
  }
}
