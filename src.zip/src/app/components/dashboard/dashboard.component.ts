import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { MainService } from '../../services/main.service';
Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  barChartData: { label: string; data: number }[] = [];
  activityChart: any; // Store the Chart instance

  constructor(private mainService: MainService) {}

  ngOnInit(): void {
    this.getDashboardDataForBarChart();
  }

  ngAfterViewInit(): void {
    this.initializeCharts();
  }

  initializeCharts(): void {
    this.renderGoalProgressChart();
    this.renderCarbonFootprintChart();
    this.renderUsageComparisonChart();
  }

  renderActivityChart(): void {
    const ctx = document.getElementById('activityChart') as HTMLCanvasElement;
    
    if (!ctx) return;

    // Extracting labels and data
    const labels = this.barChartData.map(item => item.label);
    const dataValues = this.barChartData.map(item => item.data);

    // Default values if no data available
    const finalLabels = labels.length ? labels : ['Transportation', 'Energy', 'Waste'];
    const finalData = dataValues.length ? dataValues : [21, 12, 21];

    if (this.activityChart) {
      // If chart exists, update data
      this.activityChart.data.labels = finalLabels;
      this.activityChart.data.datasets[0].data = finalData;
      this.activityChart.update();
    } else {
      // Create chart if it doesn't exist
      this.activityChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: finalLabels,
          datasets: [{
            label: 'User Activities',
            data: finalData,
            backgroundColor: ['#64B5F6', '#4CAF50', '#FF8A65']
          }]
        },
        options: {
          plugins: {
            legend: {
              display: true
            }
          }
        }
      });
    }
  }

  getDashboardDataForBarChart(): void {
    this.mainService.getDashboardDataForBarChart().subscribe({
      next: (res) => {
        console.log(res);
        
        // Transforming API response

        this.barChartData = res.map((item: any) => ({
          label: item.category?.toUpperCase(),
          data: item.goal
        }));
        this.barChartData = this.barChartData.filter((item:any)=>{
          if(item.label){
            return item;

          }
        })
        this.renderActivityChart();
      },
      error: (err) => console.error(err),
      complete: () => console.log('Data fetched successfully')
    });
  }

  renderGoalProgressChart(): void {
    const ctx = document.getElementById("goalProgressChart") as HTMLCanvasElement;
    if (!ctx) return;

    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Completed Goals', 'Remaining Goals'],
        datasets: [{
          data: [70, 30], // Replace with DB values
          backgroundColor: ['#4CAF50', '#F5F5F5']
        }]
      },
      options: {
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  }

  renderCarbonFootprintChart(): void {
    const ctx = document.getElementById("carbonFootprintChart") as HTMLCanvasElement;
    if (!ctx) return;

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['January', 'February', 'March', 'April'],
        datasets: [{
          label: 'Carbon Footprint (tons)',
          data: [1.5, 2.0, 1.8, 1.2], // Replace with DB values
          borderColor: '#FF8A65',
          fill: false
        }]
      },
      options: {
        plugins: {
          legend: {
            display: true
          }
        }
      }
    });
  }

  renderUsageComparisonChart(): void {
    const ctx = document.getElementById("usageComparisonChart") as HTMLCanvasElement;
    if (!ctx) return;

    new Chart(ctx, {
      type: 'radar',
      data: {
        labels: ['Energy', 'Transportation', 'Waste'],
        datasets: [{
          label: 'Usage Comparison',
          data: [75, 50, 90], // Replace with DB values
          backgroundColor: 'rgba(100, 181, 246, 0.5)',
          borderColor: '#64B5F6'
        }]
      },
      options: {
        plugins: {
          legend: {
            display: true
          }
        }
      }
    });
  }
}
