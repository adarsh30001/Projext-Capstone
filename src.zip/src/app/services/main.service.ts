import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class MainService {
  token: string | null = localStorage.getItem('token');

  constructor(private http: HttpClient) {}

  //for singnUp 
  onSignup(userObj: any): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/register";
    // let headers = new HttpHeaders();
    return this.http.post(apiUrl, userObj);
  }

  //ForLogin
  onLogin(userObj: any): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/login"
    return this.http.post(apiUrl, userObj);
  }

  //To Store Token
  storeToken(token: string): void {
    localStorage.setItem('authToken', token);
  }

  //To Get token
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  //check if Token Exists
  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  logout(): void {
    localStorage.removeItem('authToken');
  }

  trackActivities(activities: any): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/activities";
    return this.http.post(apiUrl, activities);
  }

  addFootprint(footprint: any): Observable<any> {
    let obj = {
      transportation: footprint.transportation,
      energyUsage: footprint.energy,
      wasteDisposal: footprint.waste,
    }
    const apiUrl = "http://localhost:3000/api/v1/carbon-footprint";
    //pass header also
    return this.http.post(apiUrl, obj, { headers: { 'Authorization': `Bearer ${this.getToken()}` } });
  }

  addgoals(goals: any): Observable<any> {
    let obj = {
      goal: goals.goalValue,
      category: goals.goalCategory
    }
    
    const apiUrl = "http://localhost:3000/api/v1/goals";
    return this.http.put(apiUrl, obj, { headers: {
      'Authorization': `Bearer ${this.getToken()}`
   }});
  }

  getDashboardDataForBarChart(): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/goals";
    return this.http.get(apiUrl, { headers: { 'Authorization': `Bearer ${this.getToken()}` } });
    }

  addTips(tip: any): Observable<any> {
      const apiUrl = "http://localhost:3000/api/v1/eco-tips";
      return this.http.post(apiUrl, tip, { headers: { 'Authorization': `Bearer ${this.getToken()}` } });
      }

  getTips(): Observable<any> {
        const apiUrl = "http://localhost:3000/api/v1/eco-tips";
        return this.http.get(apiUrl, { headers: {
          'Authorization': `Bearer ${this.getToken()}`
        } });
        }

  getGoal(): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/goals";
    return this.http.get(apiUrl,{ headers: { 'Authorization': `Bearer ${this.getToken()}` } })
  }

  getActivites() : Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/footprint";
    return this.http.get(apiUrl,{ headers: { 'Authorization': `Bearer ${this.getToken()}` } })
  }

  getProfile() : Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/profile";
    return this.http.get(apiUrl,{ headers: { 'Authorization': `Bearer ${this.getToken()}` } })
  }

  decodeJWT(token : string) {
    const payload = token.split(".")[1]
    return JSON.parse(atob(payload));
  }

  createNewGroup(name:string){
    const apiUrl = "http://localhost:3000/api/v1/group";
    const obj = {
      name: name
      }
      return this.http.post(apiUrl, obj, { headers: {
        'Authorization': `Bearer ${this.getToken()}`
        }});
  }

  // get all not joined groups
  getAllNotJoinGroups(): Observable<any> {
    const apiUrl = "http://localhost:3000/api/v1/group-notjoined";
    return this.http.get(apiUrl, { headers: {
      'Authorization': `Bearer ${this.getToken()}`
    } });
    }

  // get all joined groups
  getAllJoinedGroups(): Observable<any> {
      const apiUrl = "http://localhost:3000/api/v1/group-joined";
      return this.http.get(apiUrl, { headers: {
        'Authorization': `Bearer ${this.getToken()}`
      } });
    }

    // join a group
    joinGroup(groupId: string): Observable<any> {
      const apiUrl = `http://localhost:3000/api/v1//group/join/${groupId}`;
      
      return this.http.post(apiUrl, {}, { headers: {
        'Authorization': `Bearer ${this.getToken()}`
      } });
    }

    //send message
    sendMessage(groupId: string, message: string): Observable<any> {
      const apiUrl = `http://localhost:3000/api/v1/group/sendmessage/${groupId}`;
      const obj = {
        message: message
      }
      return this.http.post(apiUrl, obj, { headers: {
        'Authorization': `Bearer ${this.getToken()}`
      } });
    }

    // get all messages by group id
    getAllMessages(groupId: string): Observable<any> {
      const apiUrl = `http://localhost:3000/api/v1/group/messages/${groupId}`;
      return this.http.get(apiUrl, { headers: {
        'Authorization': `Bearer ${this.getToken()}`
      } });
      }
      // get group detetails by group id
      getGroupDetailsById(groupId: string): Observable<any> {
        const apiUrl = `http://localhost:3000/api/v1/group/${groupId}`;
        return this.http.get(apiUrl, { headers: {
          'Authorization': `Bearer ${this.getToken()}`
        } });
        }

 

}
