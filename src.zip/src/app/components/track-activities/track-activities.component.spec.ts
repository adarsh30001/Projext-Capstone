import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackActivitiesComponent } from './track-activities.component';

describe('TrackActivitiesComponent', () => {
  let component: TrackActivitiesComponent;
  let fixture: ComponentFixture<TrackActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrackActivitiesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrackActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
