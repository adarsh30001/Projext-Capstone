import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http";
import { AppComponent } from './app.component';
import { NavComponent } from './shared/nav/nav.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SetGoalsComponent } from './components/setgoals/setgoals.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ActivityTrackingComponent } from './components/track-activities/track-activities.component';
import { CommunitiesComponent } from './components/communities/communities.component';
import { FooterComponent } from './shared/footer/footer.component';
import { ActivityDashboardComponent } from './components/activity-dashboard/activity-dashboard.component';
import { ProgressComponent } from './components/progress/progress.component';
import { PorfileComponent } from './components/porfile/porfile.component';
import { GroupChatComponent } from './components/group-chat/group-chat.component';
import { SustainabilityComponent } from './components/sustainability/sustainability.component';
import { SustainabilityDetailComponent } from './components/sustainability-detail/sustainability-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    LoginComponent,
    SignupComponent,
    SetGoalsComponent,
    HomeComponent,
    DashboardComponent,
    ActivityTrackingComponent,
    CommunitiesComponent,
    FooterComponent,
    ActivityDashboardComponent,
    ProgressComponent,
    PorfileComponent,
    GroupChatComponent,
    SustainabilityComponent,
    SustainabilityDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
