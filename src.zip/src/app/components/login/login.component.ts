import { Component } from '@angular/core';
import { Validators, FormBuilder, FormGroup} from '@angular/forms';
import { MainService } from 'src/app/services/main.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  loginForm: FormGroup;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder,private mainService : MainService, private router : Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
 
  //For Login
  onLogin() : void {
    if (this.loginForm.valid) {
      const userObj = this.loginForm.value;
      this.mainService.onLogin(userObj).subscribe(
        (response) => {
          const token = response.token;
          //console.log(response.token);
          this.mainService.storeToken(token);
          this.successMessage = "Login Successfull"
          setTimeout(() =>{ this.router.navigate([''])},1000);
          //this.router.navigate(['']);
        },
        (error) => {
          this.errorMessage = 'Invalid login credentials'
        }
      )
    }
  }

 
}
