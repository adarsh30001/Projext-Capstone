import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sustainability',
  templateUrl: './sustainability.component.html',
  styleUrls: ['./sustainability.component.css']
})
export class SustainabilityComponent implements OnInit {
  sustainabilityOptions: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.http.get<any[]>('../../../assets/sustainability-options.json').subscribe(data => {
      this.sustainabilityOptions = data;
    });
  }

  openDetails(id: number) {
    this.router.navigate(['/sustainability', id]);
  }
}
