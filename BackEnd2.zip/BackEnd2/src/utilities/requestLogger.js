const fs = require("fs");

const requestLogger = async (req,res,next) =>{
    
    fs.appendFile("./RequestLogger.txt",req.url + " " + req.method + "\n",(err)=>{

        if(err){
            console.log("Error Logging the Request");
            
        }

       
    });

    
    next();


}

//Exporting RequestLooger as Module
module.exports = requestLogger;