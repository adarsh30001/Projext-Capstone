import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit {
  progressChart: any;
  goalData: any[] = [];
  activityData: any[] = [];

  constructor(private mainService: MainService) {}

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData() {
    this.mainService.getDashboardDataForBarChart().subscribe({
      next: (goalResponse) => {
        this.goalData = goalResponse;
        this.mainService.getActivites().subscribe({
          next: (activityResponse) => {
            this.activityData = activityResponse;
            this.createLineChart();
          }
        });
      }
    });
  }

  createLineChart() {
    const labels = this.goalData.map((goal: any) => goal.category);
    const goalValues = this.goalData.map((goal: any) => goal.goal);
    const activityValues = this.activityData.map((activity: any) => 
      Object.values(activity.dayFootPrint).slice(0, 3) // Extract values dynamically
    ).flat(); // Flatten to match goal data

    if (this.progressChart) {
      this.progressChart.destroy();
    }

    this.progressChart = new Chart("progressChart", {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Goal Set',
            data: goalValues,
            borderColor: '#27667B',
            fill: false
          },
          {
            label: 'Actual Progress',
            data: activityValues,
            borderColor: '#A0C878',
            fill: false
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }
}
