const mongoose = require("mongoose");
const {Schema,Types} = mongoose;

const url = "mongodb://localhost:27017/Ecotrakify"
const db = {};

//Creating User Schema
 const userSchema = mongoose.Schema({
    uId : {
        type : Number,
        required : true,
        unique : true

    },

    userType : {
        type : String,
        enum : ["individual","family","business"],
        default : "individual"
    },

    name: {
        type : String,
        required : true
    },

    email: {
        type : String,
        required : true,
        unique : true
    },

    password : {
        type: String,
        required : true,
    },

    carbonFootprint : {
        type : Number,
        default : 0

    },

    sustainbilityGoals : {
        type : [
            {
                goal : {
                    type : Number,
                    default : 0
                },
                category : {
                    type : String,
                    enum : ["transportation", "energyUsage",
                    "wasteDisposal"
                    ]
                },
                setAt : {
                    type : Date,
                    default : Date.now
                },

                progress : {
                    type : String,
                    default : 0
                }   
                
            }
        ]
    
    }

 }, {timeStapms : true});
//----------------------------------------------------------


//Creating FootPrintSchema
const footPrintSchema = mongoose.Schema({

    _id : {
        type : Schema.Types.ObjectId,//Same as user Id
        required : true,
        dafault : () => new Types.ObjectId() // GET New Id
    },

    dailyActivities : {

        type : [
            {
                date : {
                    type : Date,
                    required : true,
                    default : Date.now
                },
                
                dayFootPrint : {

                    type : {
                        transportation : {
                            type : Number,
                            dafault : 0
                        },

                        energyUsage : {
                            type : Number,
                            dafault : 0
                        },

                        wasteDisposal : {
                            type : Number,
                            dafault : 0
                        }

                    }

                }
            }
        ]
    }
 },{timeStapms : true});

const ecoFriendlySchema = mongoose.Schema({
   tips : {
    type : [
        {   
            tip : {
            type : String,
            required : true
            },

            name : {
                type : String,//Same as userName
                required : true, 
            }
        }
    ]
   }
},{timeStapms : true});



 //to get UserModel
db.getUserModel = async ()=> {

    try{  
        const dbConnection = await mongoose.connect(url);
        //console.log("connecton Established");
        const userModel = await dbConnection.model("User",userSchema);
        return userModel;
    }
    
    catch(err){
        console.log(err.message);
    }
}


//Get footPirntModel
db.getfootPrintModel = async ()=> {

    try{  
        const dbConnection = await mongoose.connect(url);
        //console.log("connecton Established");
        const footPirntModel = await dbConnection.model("FootPrints",footPrintSchema);
        return footPirntModel;
    }
    
    catch(err){
        console.log(err.message);
    }
}

//Get TipsModel

db.getTipsModel = async ()=>{
    const dbConnection = await mongoose.connect(url);
    const tipsModel = await dbConnection.model("Tips",ecoFriendlySchema);
    return tipsModel;
}

//create groups model
const GroupSchema = new mongoose.Schema({
    name: String,
    createdBy: mongoose.Schema.Types.ObjectId,
    members: [mongoose.Schema.Types.ObjectId],
    // createdAt: { type: Date, default: Date.now },
    // updatedAt: { type: Date, default: Date.now }
},{timeStapms : true});

db.getGroupModel = async ()=>{
    const dbConnection = await mongoose.connect(url);
    const groupModel = await dbConnection.model("Group",GroupSchema);
    return groupModel;
}

const MessageSchema = new mongoose.Schema({
    groupId: mongoose.Schema.Types.ObjectId,
    senderId: mongoose.Schema.Types.ObjectId,
    message: String
},{timeStapms : true});

db.getMessageModel = async ()=>{
    const dbConnection = await mongoose.connect(url);
    const messageModel = await dbConnection.model("Message",MessageSchema);
    return messageModel;
}
//Exporting Db as Module
module.exports = db;