import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SustainabilityDetailComponent } from './sustainability-detail.component';

describe('SustainabilityDetailComponent', () => {
  let component: SustainabilityDetailComponent;
  let fixture: ComponentFixture<SustainabilityDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SustainabilityDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SustainabilityDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
