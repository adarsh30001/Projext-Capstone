const db = require("../models/dbSetUp");
const dbModel = require("../models/model");

const dbService = {};

//Register User 1.1
dbService.registerUser = async (userObj) => {
    //console.log(userObj);
    const uId = await dbModel.registerUser(userObj);
    if(!uId) { 
        const err = new Error("Some Error Occured !! User Not Registerd");
        throw err;
    }

    return uId;
}
//-------------------------------------------------------

//Get Profile by Id 
dbService.getUserProfile = async (_id) => {
   
    const user = await  dbModel.getUserProfile(_id);

    if(!user){
        const err = new Error("User not found");
        err.status = 403;
        throw err;
    }
    return user;
}

//Get User By Email Used in /login
dbService.getUserByEmail = async (email) => {
    //validate Email Here

    const user = await dbModel.getUserByEmail(email);
    if(!user){
        const err = new Error("Email not Registered");
        err.status = 403;
        throw err;
    }

    return user;
}

//Update or Reset Password
dbService.updatePassword = async (email,password) =>{
    const upDatePassword = await dbModel.updatePassword(email,password);

    if(upDatePassword && upDatePassword.nModified == 0){
        const err = new Error("Password Reset Failed");
        err.status = 400;
        throw err; 
    }
    return ;
}
//--------------------------------------------

//update User Profile
dbService.updateUserById = async (_id,user) =>{

    const updatedUser = await dbModel.updateUserById(_id,user);
    
    if(updatedUser && updatedUser.nModified == 0){
        const err = new Error("Profile Updation Failed");
        err.status = 400;
        throw err;
    }
    return;





}

//Get All users ForAdmin
dbService.getUsers = async () =>{
    return await dbModel.getUsers();
}

//Add daily Activites
dbService.addFootPrint = async (footPrintObj) => {
    //validate Obj Here
    const addAct = await dbModel.addFootPrint(footPrintObj);
    if(!addAct) {
        const err = new Error("Invalid request body FootPrint Not Added");
        err.status = 400;
        throw err;
    }
    return ;
}

//to get Data
dbService.getFootPrint = async (_id)=>{

    const data =  await dbModel.getFootPrint(_id);
    //console.log(data);
    return data;
}

//to Add Sustainbility Goals
dbService.updateOrAddGoal = async (_id,goalsObj)=>{
    //Validate Goals Here
    const addGoal = await dbModel.updateOrAddGoal(_id,goalsObj);
    if(!addGoal || addGoal.nModified < 0){
        const err = new Error("Invaild request body goal not Added");
        err.status = 400;
        throw err
    }

    return;

}

//To get User Goals
dbService.getSutainabilityGoals = async (_id) =>{
    const goals = await dbModel.getSutainabilityGoals(_id);
    //console.log(goals);
    return goals;
 }

//To get Tips
dbService.getTips = async () =>{

    return await dbModel.getTips();
}

//To Post Tips **5.2**
dbService.postTips = async (tip) =>{
    const tips = await dbModel.postTips(tip);

    if(!tips || tips.nModified == 0 ) {
        const err = new Error("Tip Not Added Try again Later");
        err.status = 400;
        throw err;  
    }

    return;
}

// create group
dbService.createGroup=async (groupData)=>{
    return await dbModel.createGroup(groupData);
}

// get group details by id
dbService.getGroupById = async (groupId) => {
    return await dbModel.getGroupById(groupId);
}

//Get all groups
dbService.getAllGroups = async () => {
    return await dbModel.getAllGroups();
}

// join group
dbService.joinGroup = async (groupId, userId) => {
    return await dbModel.joinGroup(groupId, userId);
}

// get all not joined groups
dbService.getNotJoinedGroups = async (userId) => {
    return await dbModel.getNotJoinedGroups(userId);
}
// get all joined groups
dbService.getAllJoinedGroups = async (userId) => {
    return await dbModel.getAllJoinedGroups(userId);
}

//Send Message
dbService.sendMessage = async (message) => {
    return await dbModel.sendMessage(message);
}

// get all messages by group Id
dbService.getMessages = async (groupId) => {
    return await dbModel.getMessages(groupId);
}


    
//exporting Service
module.exports = dbService;