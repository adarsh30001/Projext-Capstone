import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './components/signup/signup.component';
import { SetGoalsComponent } from './components/setgoals/setgoals.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ActivityTrackingComponent } from './components/track-activities/track-activities.component';
import { CommunitiesComponent } from './components/communities/communities.component';
import { AuthGuard } from './guards/auth.guard';
import { ActivityDashboardComponent } from './components/activity-dashboard/activity-dashboard.component';
import { ProgressComponent } from './components/progress/progress.component';
import { PorfileComponent } from './components/porfile/porfile.component';
import { GroupChatComponent } from './components/group-chat/group-chat.component';
import { SustainabilityComponent } from './components/sustainability/sustainability.component';
import { SustainabilityDetailComponent } from './components/sustainability-detail/sustainability-detail.component';

const routes : Routes = [
  {path : "", redirectTo: "home", pathMatch : "full"},
  {path : "home", component : HomeComponent},
  {path : "profile", component : PorfileComponent},
  {path : "signup" , component : SignupComponent},
  {path : "login" , component : LoginComponent},
  {path : "set-goals" , component : SetGoalsComponent,canActivate : [AuthGuard]},
  {path : "dashboard" , component : DashboardComponent,canActivate : [AuthGuard]},
  {path : "activities" , component : ActivityTrackingComponent, canActivate : [AuthGuard]},
  {path : "communities", component : CommunitiesComponent,canActivate : [AuthGuard]},
  {path : "acitivity-dashboard", component : ActivityDashboardComponent,canActivate : [AuthGuard]},
  {path : "progress", component : ProgressComponent,canActivate : [AuthGuard]},
  {path:"group-chat/:id",component:GroupChatComponent,canActivate : [AuthGuard]},
  {path:"sustainability-options",component:SustainabilityComponent},
  { path: 'sustainability/:id', component: SustainabilityDetailComponent },
  {path : "**", redirectTo: "home", pathMatch : "full"}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports : [RouterModule]
})
export class AppRoutingModule { }
