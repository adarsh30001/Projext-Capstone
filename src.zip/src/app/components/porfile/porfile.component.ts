import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule,FormGroup } from '@angular/forms';
import { MainService } from 'src/app/services/main.service';

// interface SustainabilityGoal {
//   goal: number;
//   category: string;
//   setAt: string;
//   progress: string;
// }

// interface UserProfile {
//   uId: number;
//   userType: string;
//   name: string;
//   email: string;
//   carbonFootprint: number;
//   sustainbilityGoals: SustainabilityGoal[];
// }

@Component({
  selector: 'app-profile',
  templateUrl: './porfile.component.html',
  styleUrls: ['./porfile.component.css']
})
export class PorfileComponent implements OnInit {
  userProfile: any = {};

  constructor(private mainService : MainService) {}

  ngOnInit(): void {
    // Mock API response (Replace this with actual API call)
    this.userProfile = {
      uId: 8,
      userType: "individual",
      name: "Adarsh Kumar",
      email: "ad@gmail.com",
      carbonFootprint: 0,
      sustainbilityGoals: [
        { goal: 123, category: "energyUsage", setAt: "2025-02-12T10:54:58.457Z", progress: "0" },
        { goal: 123, category: "transportation", setAt: "2025-02-12T10:45:52.810Z", progress: "0" },
        { goal: 20, category: "wasteDisposal", setAt: "2025-02-12T10:41:27.686Z", progress: "0" }
      ]
    };
    this.getProfile();
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }
  
  getProfile(){
    this.mainService.getProfile().subscribe({
      next : (res) => {
        this.userProfile.name = res.name;
        this.userProfile.email = res.email;
        this.userProfile.uId = res.uId;
        this.userProfile.carbonFootprint = res.carbonFootprint;
        this.userProfile.sustainbilityGoals = res.sustainbilityGoals;
      }
    })
  }
}
