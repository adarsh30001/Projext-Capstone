//const jwt = require("jsonwebtoken");
//Since Adding Admin manually so no JWT
const SECRET_KEY = "@#1000aZ";

const isAdmin = (req, res, next) => {
    //token comes as Bearer + token value;
    //const token = req.headers['authorization'].split(" ")[1];


    //if (!token) return res.status(401).json({ "message": "Login or SignUp to Continue" });

    // jwt.verify(token, SECRET_KEY, (err, user) => {

    //     if (err) return res.status(403).json({ message: "Invalid token" });

    //     req.user = user;
    //     if (req.user.role !== "admin") {
    //         const err = new Error("Only Admin access alowed");
    //         err.status = 401;
    //         throw err;
    //     }
    //     next();
    // })

    const {email,password} = req.body;
    if(email !== "adarshalex201@gmail.com" && password !== "@12@!"){
        const err = new Error("Only Admin access alowed");
        err.status = 401;
        throw err;
    }
    next();
}

module.exports = isAdmin;