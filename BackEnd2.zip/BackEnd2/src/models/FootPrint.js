//class to create footprint obj
//return type {_id, dailyActivities : [{date,dayFootPrint}]}
class FootPrint{
    constructor(obj){

        this._id = obj._id;
        this.dayFootPrint = {
            transportation : obj.transportation,
            energyUsage : obj.energyUsage,
            wasteDisposal : obj.wasteDisposal
        }
        this.date = obj.date;
    }

}
module.exports = FootPrint;