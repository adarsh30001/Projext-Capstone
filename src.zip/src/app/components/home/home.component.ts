import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  // sustainabilityOptions = [
  //   {
  //     title: 'Track Recycling',
  //     description: 'Monitor your recycling habits and reduce waste.',
  //     image: 'assets/images/recycling.jpg',
  //   },
  //   {
  //     title: 'Save Energy',
  //     description: 'Track your energy usage and find ways to save.',
  //     image: 'assets/images/energy-saving.jpg',
  //   },
  //   {
  //     title: 'Eco Tips',
  //     description: 'Get daily tips to live a more sustainable life.',
  //     image: 'assets/images/eco-tips.jpg',
  //   },
  //   {
  //     title: 'Join the Community',
  //     description: 'Connect with like-minded eco-warriors.',
  //     image: 'assets/images/community.jpg',
  //   },
  //   {
  //     title: 'Reduce Water Usage',
  //     description: 'Track and minimize your water consumption.',
  //     image: 'assets/images/water-saving.jpg',
  //   },
  //   {
  //     title: 'Sustainable Travel',
  //     description: 'Plan eco-friendly travel options.',
  //     image: 'assets/images/sustainable-travel.jpg',
  //   },
  //   {
  //     title: 'Green Shopping',
  //     description: 'Discover sustainable shopping habits.',
  //     image: 'assets/images/green-shopping.jpg',
  //   },
  //   {
  //     title: 'Carbon Footprint',
  //     description: 'Calculate and reduce your carbon footprint.',
  //     image: 'assets/images/carbon-footprint.jpg',
  //   },
  // ];
  sustainabilityOptions: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}


  ngOnInit(): void {
    // Fetch sustainability options from JSON file
    this.http.get<any[]>('../../../assets/sustainability-options.json').subscribe(data => {
      this.sustainabilityOptions = data;
    });
  }
  getEcoFriendlyPastelGradient(): string {
    const pastelEcoColors = [
      '#DDEB9D', // Light Olive Green
      '#A0C878', // Moss Green
      '#B5EAD7', // Soft Mint Green
      '#C7E3BE', // Light Sage Green
      '#E2F0CB', // Pale Green
      '#CFE8A9', // Soft Lime Green
      '#F3FFE3', // Off-White Greenish Hue
    ];
    const color1 = pastelEcoColors[Math.floor(Math.random() * pastelEcoColors.length)];
    const color2 = pastelEcoColors[Math.floor(Math.random() * pastelEcoColors.length)];
    return `linear-gradient(135deg, ${color1}, ${color2})`;
  }

  goToDetails(id: number): void {
    this.router.navigate(['/sustainability', id]);
  }


}
