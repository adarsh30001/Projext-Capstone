import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MainService } from 'src/app/services/main.service';
@Component({
  selector: 'app-set-goals',
  templateUrl: './setgoals.component.html',
  styleUrls: ['./setgoals.component.css']
})
export class SetGoalsComponent implements OnInit{

  goalForm: FormGroup;
  successMessage: string = '';
  userType : any = "";
  token : any = "";
  constructor(private fb: FormBuilder,private mainService: MainService, private router : Router) {
   
      this.token = this.mainService.getToken();
      this.userType = this.mainService.decodeJWT(this.token).type;
      this.goalForm = this.fb.group({
      userType: [this.userType],
      goalCategory: [''],
      goalValue: [null, [Validators.required, Validators.min(0)]]
    });
    
  }

  ngOnInit(): void {
    this.makelineChart();
    this.getActivites();
  }

  onSubmit() {
    if (this.goalForm.valid) {
      console.log(this.goalForm.value);
      this.mainService.addgoals(this.goalForm.value).subscribe({
        next: (response) => {
          this.successMessage = 'Goals successfully set!';
          this.makelineChart();
          this.router.navigate(["/progress"]);
        }
        ,
        error: (error) => {
          this.successMessage = 'An error occurred. Please try again.';
        },
        complete: () => {
          this.goalForm.reset();
        }
      });
    } else {
      this.successMessage = 'Please fill in all the required fields';
    }
  }

  makelineChart() {
    this.mainService.getDashboardDataForBarChart().subscribe({
      next : (res) => {
       
      }
      
    })
  }

  getActivites() {
    this.mainService.getActivites().subscribe({
      next : (res) => {
        console.log("Activitie Data",res);
        

      }
   })

  }


  onSub() {
    if (this.goalForm.valid) {
      this.mainService.addgoals(this.goalForm.value).subscribe({
        next: (response) => {
          this.successMessage = 'Goals successfully set!';
          this.makelineChart();
        },
        error: (error) => {
          this.successMessage = 'An error occurred. Please try again.';
        },
        complete: () => {
          this.goalForm.reset();
          setTimeout(() => {
            window.location.reload(); // Refresh to show updated progress
          }, 1000);
        }
      });
    } else {
      this.successMessage = 'Please fill in all the required fields';
    }
  }
  
}
