//File to Fetch Data From Model and Validating It. Also Thorwing errors.
const dbService = require("../services/mainService");
const User  = require("../models/User");
const router = require("express").Router();
const jwt = require("jsonwebtoken");
const auth = require("../utilities/auth");
const isAdmin = require("./isAdmin");
const footPrintRouter = require("./footPrintRouting");
const { createGroup } = require("../models/model");

//Register a User
router.post("/register", async (req,res,next)=>{
    try{
        const userObj = new User(req.body);
        const uId = await dbService.registerUser(userObj);
        res.status(201).json({"message" : `User created Successfully with Id ${uId}`});
        next();
        
    }

    catch(err){
        next(err);
    }
});
//---------------------------------------------------------------------------

//Login User
router.post("/login", async (req,res,next)=>{

    try{
    const {email,password} = req.body;
    const user = await dbService.getUserByEmail(email);
    
    if(password === user.password){
        const SECRET_KEY = "@#1000aZ";
        //Creating JWT Token
        const token = jwt.sign({_id : user._id, name:user.name, eamil : user.email, type : user.userType},SECRET_KEY,{expiresIn : '1d'} );

        //res.cookie('jwt',token);
        res.json({token});
        next();

    }
    else{
        res.status(401).json({message : "Invalid Password"});
    }
    }

    catch(err){
        next(err);
    }

});
//--------------------------------------------------------------------------

//to Get User Profile
router.get("/profile", auth,async (req,res,next)=>{ 

    try{
        //console.log(req.user);
        const userProfile = await  dbService.getUserProfile(req.user._id);
        
        res.status(200).json(userProfile);
        next();
    }

    catch(err){
        next(err);
    }

});
//----------------------------------------------------------------------


//Forgot Password 
router.post("/forgot-password", async (req,res,next) =>{
   try {
        const {email} = req.body;
        const user = await dbService.getUserByEmail(email);
        const SECRET_KEY = "Reset@124";
        //creating token
        const token = jwt.sign({userId : user._id, email : user.email},SECRET_KEY,{expiresIn : '1h'} );

        res.cookie("jwt",token);
        res.json({"message" : `Password reset email sent`});
        next();
    }

    catch(err){
        next(err);
    }
});
//----------------------------------------------------------
//to reset password
router.post("/reset-password/:token",(req,res,next) => {   
    try{
        const {password} = req.body;
        const token = req.params.token;
        const SECRET_KEY = "Reset@124";
        //console.log(token);
        jwt.verify(token,SECRET_KEY,async (err,user)=>{
            if(err) {
                //console.log(err.message);
                return res.status(403).json({message : "Invalid token"});
            }
            req.user = user;
            await dbService.updatePassword(req.user.email,password);

            res.json({"message" : "Password reset successful"});
            next();
        });

        
    }

    catch(err){
        next(err);
    }

});

//-------------------------------------------

//to Update User
router.put("/profile",auth, async (req,res,next) =>{

    try{
        const upDatedUser = await dbService.updateUserById(req.user._id,req.body);

        res.json({"message" : "Profile updated successfully"});
        next();
    }
    catch(err){
        next(err);
    }



})

//To get all Users for Admin && change to post and Add isAdmin
router.get("/userdb",async (req,res,next)=>{

    try{
        const users = await dbService.getUsers();
        res.json({users});
        next();
    }
    catch(err){
        next(err);
    }
})
//-------------------------------------------

//Calling FootPrintRouter


//Exporting router

//api for create group
router.post('/group', auth,async (req, res,next) => {
   
    try {
        const _id = req.user._id;
        const gorupObj = {
            name : req.body.name,
            members : [_id],
            createdBy : _id
        }
        
        const createdGroup = await dbService.createGroup(gorupObj);
        res.json({createdGroup});
        next();
    }   
    catch (err) {
       next(err);
        }
});

// get group by id
router.get("/group/:groupId",async (req, res,next) => {
    try {
        const groupId = req.params.groupId;
        const group = await dbService.getGroupById(groupId);
        res.json(group);
        next();
    }   
    catch (err) {
       next(err);
    }
});

//get all groups
router.get("/group",async (req, res,next) => {
    
    try {
        const groups = await dbService.getAllGroups();
        res.json({groups});
        next();
    }   
    catch (err) {
       next(err);
        }
});

// join group
router.post('/group/join/:groupId', auth, async (req, res,next) => {
    try {
        const groupId = req.params.groupId;
        const userId = req.user._id;
        const joinGroup = await dbService.joinGroup(groupId, userId);
        res.json({joinGroup});
        next();
        }
        catch (err) {
            
            next(err);

            }
});
// get all not joined groups
router.get('/group-notjoined', auth, async (req, res,next) => {
    
    try {
        
        const userId = req.user._id;
        const notJoinedGroups = await dbService.getNotJoinedGroups(userId);
        res.json(notJoinedGroups);
        next();
        }
        catch (err) {
            next(err);
            
            }
});

// get all joined groups
router.get('/group-joined', auth, async (req, res,next) => {
    
    try {
        
        const userId = req.user._id;
        const joinedGroups = await dbService.getAllJoinedGroups(userId);
        res.json(joinedGroups);
        next();
        }
        catch (err) {
            next(err);
            }
});

//send message
router.post('/group/sendmessage/:groupId', auth, async (req, res,next) => {
    try {
        const groupId = req.params.groupId;
        const userId = req.user._id;
        const message = req.body.message;
        const messageObj = {
            groupId,
            senderId:userId,
            message
        }
        const sendMessage = await dbService.sendMessage(messageObj);
        res.json({sendMessage});
        next();
        }
        catch (err) {
            next(err);
            }
});

// get all messages of a group id
router.get('/group/messages/:groupId', auth, async (req, res,next) => {
    try {
        const groupId = req.params.groupId;
        const messages = await dbService.getMessages(groupId);
        const allMessages = [];
        for (let i = 0; i < messages.length; i++) {
            const user = await dbService.getUserProfile(messages[i].senderId);
            allMessages.push({message:messages[i].message, username:user.name,senderId:messages[i].senderId });
        }
        

        res.json(allMessages);
        next();
        }
        catch (err) {
            next(err);
            }
});
router.use(footPrintRouter);
module.exports = router;