const express = require("express");
const router = require("./routing/routing");
const cors = require('cors');
const cookieParser = require("cookie-parser");
const app =  express();

app.use(cookieParser());
app.use(cors());
app.use(express.json());

//Logging Request
app.use(require("./utilities/requestLogger"));

app.use("/api/v1",router);

app.use(require("./utilities/errorLogger"));
//Starting Server
app.listen(3000,()=>console.log("Server Started At port 3000"));
