import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-communities',
  templateUrl: './communities.component.html',
  styleUrls: ['./communities.component.css']
})
export class CommunitiesComponent implements OnInit {
  communityTips: any = [];
  ecoTipForm: FormGroup;
  groupForm: FormGroup;
  groups: { name: string; joined: boolean }[] = [
    { name: 'Renewable Energy Enthusiasts', joined: false },
    { name: 'Zero-Waste Warriors', joined: false },
    { name: 'Sustainable Living Advocates', joined: false }
  ];

  sustainabilityGroups: string[] = ['Renewable Energy Enthusiasts', 'Zero-Waste Warriors', 'Sustainable Living Advocates'];
  joinedGroups: any = [];
  notJoinedGroups: any = [];


  constructor(private fb: FormBuilder,private mainService: MainService) {
    this.ecoTipForm = this.fb.group({
      tip: ['', [Validators.required, Validators.minLength(5)]]
    });
    this.groupForm = this.fb.group({
      groupName: ['', Validators.required]
    });
  }
    ngOnInit(): void {
    this.getTips();
    this.getAllJoinedGroups();
    this.getAllNotJoinedGroups();
    }

  submitTip() {
    if (this.ecoTipForm.valid) {
      console.log('Tip Submitted:', this.ecoTipForm.value);
      this.postTip(this.ecoTipForm.value.tip);
      // Perform API call or further processing here
      this.ecoTipForm.reset(); // Clear form after submission
    } else {
      console.log('Form is invalid');
    }
  }

  addGroup() {
    if (this.groupForm.valid) {
      this.mainService.createNewGroup(this.groupForm.value.groupName).subscribe({
        next: (data) => {
          console.log('Group created:', data);
          this.groups.push({ name: this.groupForm.value.groupName, joined: false });
          this.groupForm.reset(); // Clear form after submission
          this.getAllJoinedGroups();
          this.getAllNotJoinedGroups();
          },
        error:(err)=>{
          console.log('Error creating group:', err);
        },
        complete: () => {
          console.log('Group creation complete');
          }
      })
      this.sustainabilityGroups.unshift(this.groupForm.value.groupName);
      this.groupForm.reset();
    }
  }

  getAllNotJoinedGroups() {
    this.mainService.getAllNotJoinGroups().subscribe({
      next: (data) => {
        this.notJoinedGroups = data?.map((group: any) => {
          return {name:group.name,groupId:group._id};
        });
      },
      error: (error) => {
        console.log(error);
      },
      complete: () => {
        console.log("completed");
      }
    })
  }

  getAllJoinedGroups() {
    this.mainService.getAllJoinedGroups().subscribe({
      next: (data) => {
        this.joinedGroups = data?.map((group: any) => {
          return {name:group.name,groupId:group._id};
        });
      },
      error: (error) => {
        console.log(error);
      },
      complete: () => {
        console.log("completed");
      }
    })
  }

  joinGroup(groupId: string) {
    this.mainService.joinGroup(groupId).subscribe({
      next: (data) => {
        console.log(data);
        this.getAllJoinedGroups();
        this.getAllNotJoinedGroups();
      },
      error: (error) => {
        console.log(error);
      },
      complete: () => {
        console.log("completed");
      }
      })
      }

  

 
  postTip(tip: string) {
    if (tip.trim()) {
      this.mainService.addTips({tip}).subscribe({
        next: (data) => {
          console.log(data);
          this.getTips();
        },
        error: (error) => {
          console.log(error);
        },
        complete: () => {
          console.log("completed");
        }
      })
    }
  }
  getTips() {
    this.mainService.getTips().subscribe({
      next: (data) => {
        this.communityTips = data;
      },
      error: (error) => {
        console.log(error);
      },
      complete: () => {
        console.log("completed");
      }
    })
  }


}
