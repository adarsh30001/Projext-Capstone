import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-activity-tracking',
  templateUrl: './track-activities.component.html',
  styleUrls: ['./track-activities.component.css']
})
export class ActivityTrackingComponent implements OnInit {

  activityForm: FormGroup;
  successMessage: string = '';
  userType : any = " ";
  token : any = "";

  constructor(private fb: FormBuilder,private mainService: MainService, private router : Router) {
    this.token = this.mainService.getToken();
    this.userType = this.mainService.decodeJWT(this.token).type;
   
    this.activityForm = this.fb.group({
      userType: [this.userType, Validators.required],
      date: ['', Validators.required],
      transportation: [''],
      energy: [''],
      waste: ['']
    });
      // carbonFootprint: [''],
      // energyConsumption: [''],
      // waterUsage: [''],
      // wasteGenerated: [''],
      // transportEmissions: [''], // New field for transportation emissions
      // manufacturingEmissions: [''], // New field for manufacturing emissions
      // logisticsEmissions: [''], // New field for logistics emissions
      // familyTransport: [''],
      // householdEnergy: [''],
      // recycledWaste: [''],
      // composting: ['']
   
    
  }

  ngOnInit(): void {     
  }

  trackActivities() {
    if (this.activityForm.valid) {
      this.mainService.addFootprint(this.activityForm.value).subscribe(
        {
          next: (res) => {
            setTimeout(() =>{ this.router.navigate(['/set-goals'])},1000);
            this.successMessage = 'Activity successfully tracked!';
          },
          error: (err) => {
            this.successMessage = 'An error occurred. Please try again.';
        },
        complete: () => {
          this.activityForm.reset();  
        }
      }
      );
      
      
    } else {
      this.successMessage = 'Please fill in all the required fields';
    }
  }
}
