const fs = require("fs");

const errorLogger = (err,req,res,next) =>{

    if(err){

            res.status(err.status || 500);
            
            fs.appendFile("ErrorLogger.txt",Date() + " " + err.stack + "\n",(error)=>{

            if(error){
                console.log("Error Logging the Error");
                
            }
            else{
            res.json({"message" : err.message});
            next();
            
            }
        });
    
        
    }
  
    
    


}

//Exporting RequestLooger as Module
module.exports = errorLogger;