const { urlencoded } = require("express");
const db = require("./dbSetUp");
//const dbSetUp = require("./dbSetUp");


const dbModel = {};

//Genrate Uid Cusome seriel Id;
dbModel.genrateUid = async () => {
    const userModel = await db.getUserModel();
    const users = await userModel.find();
    let uId = 0;
    if(!users) {
        uId = 1;
    }

    else {
        uId = users.length + 1;
    }
    
    return uId;

}

//Register New User
dbModel.registerUser = async (userObj) => { 
    //console.log(userObj);
    userObj.uId = await dbModel.genrateUid();
    //console.log(userObj);
    const userModel = await db.getUserModel();
    const insertion = await userModel.create(userObj);

    if(insertion){
        return userObj.uId;
    }
    return null;
}



//get User Porfile
dbModel.getUserProfile = async (_id) => { 

    const userModel = await db.getUserModel();
    // await dbModel.upDateProgress(_id);
    const user = await userModel.findOne({_id},{_id : 0, __v : 0, password : 0, "sustainbilityGoals._id" : 0});
    //console.log(user);
    return (user || null);
    

}

//Get User By Email //Login
dbModel.getUserByEmail = async (email) => {
    const userModel = await db.getUserModel();
    const user = userModel.findOne({email});
    
    return (user || null);
}
//----------------------------------------

//to Reset and Update password
dbModel.updatePassword = async (email,password) =>{
    const userModel = await db.getUserModel();
    const upDatePassword = await userModel.updateOne({email},{$set : {"password" : password}});
    return upDatePassword;
}
//--------------------------------------------

//Update User Profile
dbModel.updateUserById = async (_id,user) => {

    const userModel = await db.getUserModel();

    return await userModel.findOneAndUpdate({_id},{...user});
}
//----------------------------------------------------

//forAdmin to get All users
dbModel.getUsers = async ()=>{

    const userModel = await db.getUserModel();
    const users  = await userModel.find();
    return (users || null);
}

//To track carbonfootprint of day ##3.1
dbModel.addFootPrint = async (footPrintObj)=>{

    const footPirntModel = await db.getfootPrintModel();
    // const activitiesArray = await footPirntModel.findOne({_id},{_id : 0});

   const addAct = await footPirntModel.updateOne({_id :footPrintObj._id}, {$push : {dailyActivities : {"date" : footPrintObj.date, dayFootPrint : footPrintObj.dayFootPrint}}}, {upsert : true});

   //console.log(addAct);

   return addAct;
}
//------------------------------------------------

//to get footPrint **For Admin**
dbModel.getFootPrint = async (_id) => {
    const footPrintModel = await db.getfootPrintModel();

    return await footPrintModel.findOne({_id});
}
//---------------------------------------

//to Add New Sustainability Goals  or Update Sustainablity Goals ##4.1 and ##4.3
dbModel.updateOrAddGoal = async(_id,goalsObj) =>{
    const userModel = await db.getUserModel();
    const addGoal = await userModel.updateOne({_id,"sustainbilityGoals.category" : goalsObj.category},{
        $set : {"sustainbilityGoals.$" : goalsObj}
    });
    if(addGoal.matchedCount === 0){
        addGoal = await userModel.updateOne({_id},{
            $push : {sustainbilityGoals : goalsObj}
        });
    }
    return addGoal;
}

//------------------##4.1-----------Get Goals----------
//to get user goals
dbModel.getSutainabilityGoals = async (_id) =>{
    const userModel = await db.getUserModel();
    //calculate Progress Here

    const goals = await userModel.findOne({_id},{_id :0 ,sustainbilityGoals: 1});
    
    return goals.sustainbilityGoals;
}

//To get Daily Activties of User; return []
dbModel.getDailyActivites = async (_id) =>{
    const footPrintModel = await db.getfootPrintModel();
    const activities = await footPrintModel.findOne({_id},{_id : 0,__v : 0});
    //console.log(activities);
    if(!activities) return null;
    return activities.dailyActivities;
}
//Calculate Progress and Update Progress for the Goals.
dbModel.upDateProgress = async (_id) =>{

    const userModel = await db.getUserModel();
    const goals = await dbModel.getSutainabilityGoals(_id);
    //console.log(goals);
    if(!goals) return;

    const activities = await dbModel.getDailyActivites(_id); 
    if(!activities) return;

    let actOnGoalDate,usageDiff,actAfterGoal,lastDayAct;
    let targetDate;
     
    for(let i of goals){
        //targetDate = 
        actOnGoalDate = activities.find((activity) => new Date(activity.date).toISOString().split("T")[0] == new Date(i.setAt).toISOString().split("T")[0]
        );
        //console.log(actOnGoalDate);
        actAfterGoal = activities.filter(activity => new Date(activity.date).toISOString().split("T")[0] >  new Date(i.setAt).toISOString().split("T")[0]);

        lastDayAct = actAfterGoal.sort()[actAfterGoal.length -1];

        usageDiff = actOnGoalDate.dayFootPrint[i.category] - lastDayAct.dayFootPrint[i.category];
        if(usageDiff <= 0) {
            continue;
        }
        progress = Math.trunc((usageDiff * 100) / Number(actOnGoalDate.dayFootPrint[i.category]));
        await userModel.updateOne({_id,"sustainbilityGoals.category" : i.category},{"sustainbilityGoals.$.progress" : progress});

        //Will Not work why???
        //  await userModel.findO(({_id, "sustainbilityGoals.category" : i.category},{$set : {"sustainbilityGoals.$.progress" : progress}}));

    }

    return;

}

//Get Tips **5.1**
dbModel.getTips = async () =>{
    const tipsModel = await db.getTipsModel();
    const tips = await tipsModel.find();
    
    return tips;
}

//Post tips by User **5.2**
dbModel.postTips = async (tip) =>{
    const tipsModel = await db.getTipsModel();
    const addTips = await tipsModel.updateOne({},{$push : {"tips" : tip}},{upsert : true});
    //console.log(addTips);
    return addTips;
}


//create group
dbModel.createGroup= async (groupData)=>{
    const groupModel= await db.getGroupModel();
    const createGroup = await  groupModel.create(groupData);
    return createGroup;
}
// get group details by id
dbModel.getGroupById = async (groupId) => {
    const groupModel = await db.getGroupModel();
    const group = await groupModel.findOne({_id : groupId});
    return group;
}

//get all groups
dbModel.getAllGroups = async () =>{
    const groupModel = await db.getGroupModel();
    return await groupModel.find();
}

// join group
dbModel.joinGroup = async (groupId,userId) => {
    const groupModel = await db.getGroupModel();
    console.log(userId,groupId);
    const joinGroup = await groupModel.updateOne({_id : groupId},{$push : {members : userId}});
    console.log(joinGroup);
    return joinGroup;
}

// getv all not joined groups
dbModel.getNotJoinedGroups = async (userId) => {
    
    const groupModel = await db.getGroupModel();
    
    const notJoinedGroups = await groupModel.find({members : {$ne : userId}});
   
    return notJoinedGroups;
    }


// get all joined groups
dbModel.getAllJoinedGroups = async (userId) => {
    const groupModel = await db.getGroupModel();
    const joinedGroups = await groupModel.find({members : userId});
    return joinedGroups;
}


// send message
dbModel.sendMessage = async (message) => {
    const messageModel = await db.getMessageModel();
    const addMessage = await messageModel.create(message);
    return addMessage;
}

// get all message by group id
dbModel.getMessages = async (groupId) => {
    const messageModel = await db.getMessageModel();
    const messages = await messageModel
    .find({groupId})
    .sort({createdAt : 1});
    return messages;
    }
//Exporting dbModel as module




module.exports = dbModel;

